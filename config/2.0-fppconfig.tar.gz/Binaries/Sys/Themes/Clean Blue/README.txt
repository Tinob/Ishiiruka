By Michael "MaJoR" Roesch of the Dolphin team

dolphin-emu.org